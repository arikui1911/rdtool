require 'rd/version'
module RD
  PACKAGE_VERSION = RD::VERSION
end
